from app.utils.http import post_edit, download_file
from app.services.all_promot import get_prompt
from app.utils.response import extract_output_urls
import logging
logger = logging.getLogger("mcpp.information")

OUTPUT_FILE = "information.png"

def run():
    logger.info("Start information job")
    prompt = get_prompt("information")
    payload = {
        "aspect_ratio": "1:1",
        "resolution": "2k",
        "enable_sync_mode": True,
        "enable_base64_output": False,
        "images": [
            images["edit"],
            images["ref1"],
            images["ref2"],
            images["ref3"],
        ],
        "prompt": prompt,
    }

    result = post_edit(payload)
    output_url = extract_output_urls(result)[0]

    content = download_file(output_url)
    logger.info(f"Information image saved to {OUTPUT_FILE}")
    with open(OUTPUT_FILE, "wb") as f:
        f.write(content)

    return {
        "job": "information",
        "output_url": output_url,
        "file": OUTPUT_FILE,
    }
