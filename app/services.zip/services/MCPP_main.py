# app/services/MCPP_main.py
from app.utils.http import post_edit, download_file
from app.services.all_promot import get_prompt
from pathlib import Path
from app.utils.response import extract_output_urls
import logging
logger = logging.getLogger("mcpp.main")

OUT_DIR = Path("outputs")
OUT_DIR.mkdir(exist_ok=True)

def run():
    logger.info("Start main job")
    prompt = get_prompt("main")
    payload = {
        "prompt": prompt,
        "images": [
            images["edit"],
            images["ref1"],
            images["ref2"],
            images["ref3"],
        ],
        "aspect_ratio": "1:1",
        "resolution": "1k",
        "enable_sync_mode": True,
        "enable_base64_output": False,
    }

    result = post_edit(payload)
    output_urls = extract_output_urls(result)
    logger.info(f"Main batch job received {len(output_urls)} output URLs")
    
    saved = []
    for i, url in enumerate(output_urls, start=1):
        content = download_file(url)
        filename = OUT_DIR / f"output_{i}.png"
        filename.write_bytes(content)
        saved.append(str(filename))
        logger.info(f"Main batch image {i} saved to {filename}")

    return {
        "job": "main_batch",
        "count": len(saved),
        "files": saved,
    }
