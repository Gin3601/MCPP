# app/services/MCPP_bigplate.py
from app.utils.http import post_edit, download_file
from app.services.all_promot import get_prompt
from app.utils.response import extract_output_urls
import logging
logger = logging.getLogger("mcpp.bigplate")
OUTPUT_FILE = "bigplate.png"

def run():
    logger.info("Start bigplate job")
    prompt = get_prompt("bigplate") 
    payload = {
        "aspect_ratio": "1:1",
        "resolution": "1k",
        "enable_sync_mode": True,
        "enable_base64_output": False,
        "images": [
            images["ref1"],
            images["ref2"],
        ],
        "prompt": prompt
    }

    result = post_edit(payload)
    output_url = extract_output_urls(result)[0]

    content = download_file(output_url)
    logger.info(f"Bigplate image saved to {OUTPUT_FILE}")
    with open(OUTPUT_FILE, "wb") as f:
        f.write(content)

    return {
        "job": "bigplate",
        "output_url": output_url,
        "file": OUTPUT_FILE
    }
