# app/services/MCPP_samllplate.py
from app.utils.http import post_edit, download_file
from app.services.all_promot import get_prompt
from app.utils.response import extract_output_urls
import logging  
logger = logging.getLogger("mcpp.smallplate")

OUTPUT_FILE = "smallplate.png"

def run():
    logger.info("Start smallplate job")
    prompt = get_prompt("smallplate")
    payload = {
        "aspect_ratio": "1:1",
        "resolution": "1k",
        "enable_sync_mode": True,
        "enable_base64_output": False,
        "images": [
            images["ref1"],
            images["ref3"],
        ],
        "prompt": prompt
    }

    result = post_edit(payload)
    output_url = extract_output_urls(result)[0]
    
    content = download_file(output_url)
    with open(OUTPUT_FILE, "wb") as f:
        f.write(content)
    logger.info(f"Smallplate image saved to {OUTPUT_FILE}")

    return {
        "job": "smallplate",
        "output_url": output_url,
        "file": OUTPUT_FILE
    }
