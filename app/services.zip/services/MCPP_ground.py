# app/services/MCPP_ground.py
from app.utils.http import post_edit, download_file
from app.services.all_promot import get_prompt
from app.utils.response import extract_output_urls
import logging
logger = logging.getLogger("mcpp.ground")

OUTPUT_FILE = "table_scene.png"

def run():
    logger.info("Start ground job")
    prompt = get_prompt("ground")
    payload = {
        "aspect_ratio": "1:1",
        "resolution": "2k",
        "enable_sync_mode": True,
        "enable_base64_output": False,
        "images": [
            images["edit"],
            images["ref1"],
            images["ref2"],
        ],
        "prompt": prompt
    }

    result = post_edit(payload)
    output_url = extract_output_urls(result)[0]

    content = download_file(output_url)
    logger.info(f"Ground scene image saved to {OUTPUT_FILE}")
    with open(OUTPUT_FILE, "wb") as f:
        f.write(content)

    return {
        "job": "ground_scene",
        "output_url": output_url,
        "file": OUTPUT_FILE
    }
